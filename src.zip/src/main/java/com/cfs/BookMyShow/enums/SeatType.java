package com.cfs.BookMyShow.enums;

public enum SeatType {
    Regular,
    Premium,
    VIP
}
